Authors of these 4 functions are detailed in their respective preamble. 
